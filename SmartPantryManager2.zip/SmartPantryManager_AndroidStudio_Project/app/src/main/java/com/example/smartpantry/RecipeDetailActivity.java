package com.example.smartpantry;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class RecipeDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);

        int targetId = getIntent().getIntExtra("id", -1);

        DBHelper db = new DBHelper(this);
        Recipe recipe = null;
        String rawIngredients = "";

        Cursor cursor = db.getAllRecipes();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                if (id == targetId) {
                    String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                    rawIngredients = cursor.getString(cursor.getColumnIndexOrThrow("ingredients"));
                    String steps = cursor.getString(cursor.getColumnIndexOrThrow("steps"));

                    recipe = new Recipe(id, name, new ArrayList<>(), steps);
                    break;
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        if (recipe == null) {
            finish();
            return;
        }

        TextView tvName = findViewById(R.id.tvRecipeName);
        TextView tvIngredients = findViewById(R.id.tvIngredients);
        TextView tvSteps = findViewById(R.id.tvSteps);

        if (tvName != null) tvName.setText(recipe.name);
        if (tvIngredients != null) tvIngredients.setText("Ingredients:\n" + rawIngredients);
        if (tvSteps != null) tvSteps.setText("Steps:\n" + recipe.steps);
    }
}