package com.example.smartpantry;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PantryAdapter extends RecyclerView.Adapter<PantryAdapter.VH> {

    public interface Listener {
        void edit(Ingredient i);
        void delete(Ingredient i);
    }

    private List<Ingredient> data;
    private final Listener listener;

    public PantryAdapter(List<Ingredient> data, Listener listener) {
        this.data = data;
        this.listener = listener;
    }

    public void setData(List<Ingredient> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pantry, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Ingredient i = data.get(pos);

        String displayText = i.name + " — " + i.quantity + " " + i.unit;
        h.item.setText(displayText);

        if (i.expiry == null || i.expiry.isEmpty()) {
            h.expiry.setText("No expiry date");
        } else {
            h.expiry.setText("Expires: " + i.expiry);
        }

        h.edit.setOnClickListener(v -> listener.edit(i));
        h.del.setOnClickListener(v -> listener.delete(i));
    }

    @Override
    public int getItemCount() {
        return data != null ? data.size() : 0;
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView item, expiry;
        Button edit, del;

        VH(View v) {
            super(v);
            item = v.findViewById(R.id.tvPantryItemName);
            expiry = v.findViewById(R.id.tvExpiryDate);
            edit = v.findViewById(R.id.btnEdit);
            del = v.findViewById(R.id.btnDelete);
        }
    }
}