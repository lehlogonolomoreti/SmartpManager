package com.example.smartpantry;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class SuggestedRecipesActivity extends AppCompatActivity {

    private static final String TAG = "SuggestedRecipes";
    private DBHelper db;
    private RecyclerView rv;
    private TextView tvEmpty;
    private Button btnToggle;
    private boolean showOnlyCanMake = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggested);

        db = new DBHelper(this);

        rv = findViewById(R.id.rvSuggested);
        tvEmpty = findViewById(R.id.tvEmptyState);
        btnToggle = findViewById(R.id.btnToggleFilter);

        if (rv != null) {
            rv.setLayoutManager(new LinearLayoutManager(this));
        }

        if (btnToggle != null) {
            btnToggle.setOnClickListener(v -> {
                showOnlyCanMake = !showOnlyCanMake;
                btnToggle.setText(showOnlyCanMake ? "Show All Recipes" : "Show Only Matchable Recipes");
                loadRecipes();
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadRecipes();
    }

    private void loadRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = showOnlyCanMake ? db.getSuggestedRecipes() : db.getAllRecipes();
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));

                    // Fallback to "instructions" if "steps" column is named differently
                    String steps = "";
                    int stepsIdx = cursor.getColumnIndex("steps");
                    if (stepsIdx == -1) {
                        stepsIdx = cursor.getColumnIndex("instructions");
                    }
                    if (stepsIdx != -1) {
                        steps = cursor.getString(stepsIdx);
                    }

                    List<Recipe.RecipeIngredient> ingredients = getIngredientsForRecipe(id);
                    recipes.add(new Recipe(id, name, ingredients, steps));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading recipes from database", e);
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }

        RecipeAdapter adapter = new RecipeAdapter(recipes, recipe -> {
            Intent intent = new Intent(SuggestedRecipesActivity.this, RecipeDetailActivity.class);
            intent.putExtra("id", recipe.id);
            startActivity(intent);
        });

        if (rv != null) {
            rv.setAdapter(adapter);
            rv.setVisibility(recipes.isEmpty() ? View.GONE : View.VISIBLE);
        }

        if (tvEmpty != null) {
            tvEmpty.setVisibility(recipes.isEmpty() ? View.VISIBLE : View.GONE);
        }
    }

    private List<Recipe.RecipeIngredient> getIngredientsForRecipe(long recipeId) {
        List<Recipe.RecipeIngredient> list = new ArrayList<>();
        Cursor ingCursor = null;
        try {
            ingCursor = db.getRecipeIngredients(recipeId);
            if (ingCursor != null && ingCursor.moveToFirst()) {
                do {
                    // Check column variations for ingredient name
                    int nameIdx = ingCursor.getColumnIndex("name");
                    if (nameIdx == -1) {
                        nameIdx = ingCursor.getColumnIndex("ingredient_name");
                    }
                    String ingName = (nameIdx != -1) ? ingCursor.getString(nameIdx) : "";

                    // Check column variations for required quantity
                    int qtyIdx = ingCursor.getColumnIndex("quantity");
                    if (qtyIdx == -1) {
                        qtyIdx = ingCursor.getColumnIndex("required_qty");
                    }
                    double qty = (qtyIdx != -1) ? ingCursor.getDouble(qtyIdx) : 0.0;

                    int unitIdx = ingCursor.getColumnIndex("unit");
                    String unit = (unitIdx != -1) ? ingCursor.getString(unitIdx) : "";

                    list.add(new Recipe.RecipeIngredient(ingName, qty, unit));
                } while (ingCursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading recipe ingredients", e);
        } finally {
            if (ingCursor != null && !ingCursor.isClosed()) {
                ingCursor.close();
            }
        }
        return list;
    }
}