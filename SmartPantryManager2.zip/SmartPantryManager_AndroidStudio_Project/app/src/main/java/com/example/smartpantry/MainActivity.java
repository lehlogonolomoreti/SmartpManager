package com.example.smartpantry;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DBHelper db;
    private PantryAdapter adapter;
    private RecyclerView rv;
    private TextView summary, tvArrow;
    private DrawerLayout drawerLayout;
    private LinearLayout layoutDropdownHeader;
    private boolean isExpanded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBHelper(this);

        drawerLayout = findViewById(R.id.drawerLayout);
        rv = findViewById(R.id.rvPantry);
        summary = findViewById(R.id.tvPantryCount);
        tvArrow = findViewById(R.id.tvArrow);
        layoutDropdownHeader = findViewById(R.id.layoutDropdownHeader);

        ImageButton btnOpenDrawer = findViewById(R.id.btnOpenDrawer);

        NavigationView navigationView = findViewById(R.id.navigationView);
        if (navigationView != null) {
            navigationView.setNavigationItemSelectedListener(this);
        }

        if (btnOpenDrawer != null) {
            btnOpenDrawer.setOnClickListener(v -> {
                if (drawerLayout != null) {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            });
        }

        // Dropdown toggle logic
        if (layoutDropdownHeader != null) {
            layoutDropdownHeader.setOnClickListener(v -> {
                isExpanded = !isExpanded;
                if (rv != null) {
                    rv.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
                }
                if (tvArrow != null) {
                    tvArrow.setText(isExpanded ? "▲" : "▼");
                }
            });
        }

        if (rv != null) {
            rv.setLayoutManager(new LinearLayoutManager(this));
        }

        adapter = new PantryAdapter(new ArrayList<>(), new PantryAdapter.Listener() {
            @Override
            public void edit(Ingredient i) {
                Intent intent = new Intent(MainActivity.this, AddEditIngredientActivity.class);
                intent.putExtra("id", i.id);
                intent.putExtra("name", i.name);
                intent.putExtra("quantity", i.quantity);
                intent.putExtra("unit", i.unit);
                intent.putExtra("expiry", i.expiry);
                startActivity(intent);
            }

            @Override
            public void delete(Ingredient i) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete ingredient?")
                        .setMessage("Delete " + i.name + "?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            db.deleteIngredient(i.id);
                            load();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });

        if (rv != null) {
            rv.setAdapter(adapter);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.nav_pantry) {
            // Automatically expand list when selecting "My Pantry" from sidebar
            isExpanded = true;
            if (rv != null) rv.setVisibility(View.VISIBLE);
            if (tvArrow != null) tvArrow.setText("▲");
            load();
        } else if (itemId == R.id.nav_add_ingredient) {
            startActivity(new Intent(MainActivity.this, AddEditIngredientActivity.class));
        } else if (itemId == R.id.nav_suggested_recipes) {
            startActivity(new Intent(MainActivity.this, SuggestedRecipesActivity.class));
        } else if (itemId == R.id.nav_settings) {
            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
        }

        if (drawerLayout != null) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        List<Ingredient> ingredients = new ArrayList<>();
        Cursor cursor = db.getAllIngredients();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                double quantity = cursor.getDouble(cursor.getColumnIndexOrThrow("quantity"));
                String unit = cursor.getString(cursor.getColumnIndexOrThrow("unit"));

                int expiryIndex = cursor.getColumnIndexOrThrow("expiry");
                String expiry = cursor.isNull(expiryIndex) ? "" : cursor.getString(expiryIndex);

                ingredients.add(new Ingredient(id, name, quantity, unit, expiry));
            } while (cursor.moveToNext());

            cursor.close();
        }

        if (adapter != null) {
            adapter.setData(ingredients);
        }

        if (summary != null) {
            summary.setText(ingredients.size() + " pantry item(s) saved locally");
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout != null && drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}