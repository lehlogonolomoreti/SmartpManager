package com.example.smartpantry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    // ==============================
    // DATABASE INFORMATION
    // ==============================

    private static final String DB_NAME = "smart_pantry.db";
    private static final int DB_VERSION = 2; // Incremented to trigger database upgrade & refresh


    // ==============================
    // CONSTRUCTOR
    // ==============================

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    // ==============================
    // CREATE DATABASE
    // ==============================

    @Override
    public void onCreate(SQLiteDatabase db) {

        // ------------------------------
        // PANTRY TABLE
        // ------------------------------

        db.execSQL(
                "CREATE TABLE pantry (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "quantity REAL NOT NULL, " +
                        "unit TEXT NOT NULL, " +
                        "expiry TEXT" +
                        ")"
        );


        // ------------------------------
        // RECIPES TABLE
        // ------------------------------

        db.execSQL(
                "CREATE TABLE recipes (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "steps TEXT NOT NULL" +
                        ")"
        );


        // ------------------------------
        // RECIPE INGREDIENTS TABLE
        // ------------------------------

        db.execSQL(
                "CREATE TABLE recipe_ingredients (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "recipe_id INTEGER NOT NULL, " +
                        "name TEXT NOT NULL, " +
                        "quantity REAL NOT NULL, " +
                        "unit TEXT NOT NULL, " +
                        "FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE" +
                        ")"
        );


        // Add the built-in recipes
        seedRecipes(db);
    }


    // ==============================
    // DATABASE UPGRADE
    // ==============================

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS recipe_ingredients");
        db.execSQL("DROP TABLE IF EXISTS recipes");
        db.execSQL("DROP TABLE IF EXISTS pantry");

        onCreate(db);
    }


    // =========================================================
    // PANTRY METHODS
    // =========================================================


    // ==============================
    // ADD PANTRY INGREDIENT
    // ==============================

    public long addIngredient(
            String name,
            double quantity,
            String unit,
            String expiry) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("quantity", quantity);
        values.put("unit", unit);

        if (expiry == null || expiry.trim().isEmpty()) {
            values.putNull("expiry");
        } else {
            values.put("expiry", expiry);
        }

        return db.insert("pantry", null, values);
    }

    // Alias method to match AddEditIngredientActivity calls
    public long insertIngredient(
            String name,
            double quantity,
            String unit,
            String expiry) {
        return addIngredient(name, quantity, unit, expiry);
    }


    // ==============================
    // UPDATE PANTRY INGREDIENT
    // ==============================

    public int updateIngredient(
            int id,
            String name,
            double quantity,
            String unit,
            String expiry) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("quantity", quantity);
        values.put("unit", unit);

        if (expiry == null || expiry.trim().isEmpty()) {
            values.putNull("expiry");
        } else {
            values.put("expiry", expiry);
        }

        return db.update(
                "pantry",
                values,
                "id=?",
                new String[]{String.valueOf(id)}
        );
    }


    // ==============================
    // DELETE PANTRY INGREDIENT
    // ==============================

    public int deleteIngredient(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(
                "pantry",
                "id=?",
                new String[]{String.valueOf(id)}
        );
    }


    // ==============================
    // GET ALL PANTRY INGREDIENTS
    // ==============================

    public Cursor getAllIngredients() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                "pantry",
                null,
                null,
                null,
                null,
                null,
                "name ASC"
        );
    }


    // ==============================
    // GET ONE PANTRY INGREDIENT
    // ==============================

    public Cursor getIngredient(int id) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                "pantry",
                null,
                "id=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );
    }


    // ==============================
    // COUNT PANTRY ITEMS
    // ==============================

    public int getPantryCount() {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM pantry",
                null
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();

        return count;
    }


    // =========================================================
    // RECIPE METHODS
    // =========================================================


    // ==============================
    // ADD RECIPE
    // ==============================

    public long addRecipe(
            String name,
            String steps) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("steps", steps);

        return db.insert(
                "recipes",
                null,
                values
        );
    }


    // ==============================
    // GET ALL RECIPES
    // ==============================

    public Cursor getAllRecipes() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                "recipes",
                null,
                null,
                null,
                null,
                null,
                "name ASC"
        );
    }


    // ==============================
    // GET ONE RECIPE
    // ==============================

    public Cursor getRecipe(int recipeId) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                "recipes",
                null,
                "id=?",
                new String[]{String.valueOf(recipeId)},
                null,
                null,
                null
        );
    }


    // ==============================
    // UPDATE RECIPE
    // ==============================

    public int updateRecipe(
            int recipeId,
            String name,
            String steps) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("steps", steps);

        return db.update(
                "recipes",
                values,
                "id=?",
                new String[]{String.valueOf(recipeId)}
        );
    }


    // ==============================
    // DELETE RECIPE
    // ==============================

    public int deleteRecipe(int recipeId) {

        SQLiteDatabase db = this.getWritableDatabase();

        // Delete ingredients belonging to the recipe
        db.delete(
                "recipe_ingredients",
                "recipe_id=?",
                new String[]{String.valueOf(recipeId)}
        );

        // Delete recipe
        return db.delete(
                "recipes",
                "id=?",
                new String[]{String.valueOf(recipeId)}
        );
    }


    // =========================================================
    // RECIPE INGREDIENT METHODS
    // =========================================================


    // ==============================
    // ADD RECIPE INGREDIENT
    // ==============================

    public long addRecipeIngredient(
            long recipeId,
            String name,
            double quantity,
            String unit) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("recipe_id", recipeId);
        values.put("name", name);
        values.put("quantity", quantity);
        values.put("unit", unit);

        return db.insert(
                "recipe_ingredients",
                null,
                values
        );
    }


    // ==============================
    // GET INGREDIENTS FOR RECIPE
    // ==============================

    public Cursor getRecipeIngredients(long recipeId) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                "recipe_ingredients",
                null,
                "recipe_id=?",
                new String[]{String.valueOf(recipeId)},
                null,
                null,
                "name ASC"
        );
    }


    // ==============================
    // DELETE RECIPE INGREDIENT
    // ==============================

    public int deleteRecipeIngredient(int ingredientId) {

        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(
                "recipe_ingredients",
                "id=?",
                new String[]{String.valueOf(ingredientId)}
        );
    }


    // =========================================================
    // SUGGESTED RECIPES
    // =========================================================


    // ==============================
    // GET RECIPES THAT CAN BE MADE
    // ==============================

    public Cursor getSuggestedRecipes() {

        SQLiteDatabase db = this.getReadableDatabase();

        /*
         * A recipe is suggested when every required ingredient
         * exists in the user's pantry.
         *
         * Uses flexible case-insensitive partial string matching (LIKE)
         * to prevent mismatches from singular/plural naming differences.
         */

        String query =
                "SELECT r.id, r.name, r.steps " +
                        "FROM recipes r " +
                        "WHERE NOT EXISTS (" +
                        "SELECT 1 " +
                        "FROM recipe_ingredients ri " +
                        "WHERE ri.recipe_id = r.id " +
                        "AND NOT EXISTS (" +
                        "SELECT 1 " +
                        "FROM pantry p " +
                        "WHERE LOWER(TRIM(p.name)) LIKE '%' || LOWER(TRIM(ri.name)) || '%' " +
                        "OR LOWER(TRIM(ri.name)) LIKE '%' || LOWER(TRIM(p.name)) || '%'" +
                        ")" +
                        ") " +
                        "ORDER BY r.name ASC";

        return db.rawQuery(query, null);
    }


    // =========================================================
    // BUILT-IN RECIPES
    // =========================================================

    private void seedRecipes(SQLiteDatabase db) {


        // =====================================================
        // 1. TOMATO PASTA
        // =====================================================

        long recipe1 = insertRecipe(
                db,
                "Tomato Pasta",
                "1. Boil the pasta.\n" +
                        "2. Cook the tomatoes with garlic.\n" +
                        "3. Add the cooked pasta.\n" +
                        "4. Mix well and serve."
        );

        insertRecipeIngredient(db, recipe1, "pasta", 200, "g");
        insertRecipeIngredient(db, recipe1, "tomato", 3, "pcs");
        insertRecipeIngredient(db, recipe1, "garlic", 2, "pcs");


        // =====================================================
        // 2. PANCAKES
        // =====================================================

        long recipe2 = insertRecipe(
                db,
                "Pancakes",
                "1. Mix the flour, eggs and milk.\n" +
                        "2. Heat a frying pan.\n" +
                        "3. Pour the mixture into the pan.\n" +
                        "4. Cook both sides until golden."
        );

        insertRecipeIngredient(db, recipe2, "flour", 200, "g");
        insertRecipeIngredient(db, recipe2, "egg", 2, "pcs");
        insertRecipeIngredient(db, recipe2, "milk", 250, "ml");


        // =====================================================
        // 3. VEGETABLE STIR FRY
        // =====================================================

        long recipe3 = insertRecipe(
                db,
                "Vegetable Stir Fry",
                "1. Chop the vegetables.\n" +
                        "2. Heat oil in a pan.\n" +
                        "3. Add the vegetables.\n" +
                        "4. Stir fry until cooked."
        );

        insertRecipeIngredient(db, recipe3, "broccoli", 200, "g");
        insertRecipeIngredient(db, recipe3, "carrot", 2, "pcs");
        insertRecipeIngredient(db, recipe3, "pepper", 1, "pcs");


        // =====================================================
        // 4. EGG SANDWICH
        // =====================================================

        long recipe4 = insertRecipe(
                db,
                "Egg Sandwich",
                "1. Boil the eggs.\n" +
                        "2. Mash the eggs.\n" +
                        "3. Add seasoning.\n" +
                        "4. Spread onto bread and serve."
        );

        insertRecipeIngredient(db, recipe4, "egg", 2, "pcs");
        insertRecipeIngredient(db, recipe4, "bread", 2, "slices");


        // =====================================================
        // 5. FRUIT SALAD
        // =====================================================

        long recipe5 = insertRecipe(
                db,
                "Fruit Salad",
                "1. Wash the fruit.\n" +
                        "2. Cut the fruit into small pieces.\n" +
                        "3. Mix everything together.\n" +
                        "4. Serve chilled."
        );

        insertRecipeIngredient(db, recipe5, "apple", 1, "pcs");
        insertRecipeIngredient(db, recipe5, "banana", 2, "pcs");
        insertRecipeIngredient(db, recipe5, "orange", 1, "pcs");


        // =====================================================
        // 6. GARLIC BREAD
        // =====================================================

        long recipe6 = insertRecipe(
                db,
                "Garlic Bread",
                "1. Mix garlic with butter.\n" +
                        "2. Spread the mixture over the bread.\n" +
                        "3. Bake until golden brown.\n" +
                        "4. Serve warm."
        );

        insertRecipeIngredient(db, recipe6, "bread", 4, "slices");
        insertRecipeIngredient(db, recipe6, "garlic", 2, "pcs");
        insertRecipeIngredient(db, recipe6, "butter", 50, "g");


        // =====================================================
        // 7. CHEESE OMELETTE
        // =====================================================

        long recipe7 = insertRecipe(
                db,
                "Cheese Omelette",
                "1. Beat the eggs.\n" +
                        "2. Heat a frying pan.\n" +
                        "3. Add the eggs and cheese.\n" +
                        "4. Fold and cook until ready."
        );

        insertRecipeIngredient(db, recipe7, "egg", 3, "pcs");
        insertRecipeIngredient(db, recipe7, "cheese", 50, "g");


        // =====================================================
        // 8. CHICKEN RICE
        // =====================================================

        long recipe8 = insertRecipe(
                db,
                "Chicken Rice",
                "1. Cook the rice.\n" +
                        "2. Cook the chicken in a pan.\n" +
                        "3. Add vegetables.\n" +
                        "4. Mix with the cooked rice and serve."
        );

        insertRecipeIngredient(db, recipe8, "rice", 200, "g");
        insertRecipeIngredient(db, recipe8, "chicken", 250, "g");
        insertRecipeIngredient(db, recipe8, "carrot", 1, "pcs");


        // =====================================================
        // 9. TOMATO SALAD
        // =====================================================

        long recipe9 = insertRecipe(
                db,
                "Tomato Salad",
                "1. Wash the tomatoes.\n" +
                        "2. Cut the tomatoes.\n" +
                        "3. Add seasoning.\n" +
                        "4. Mix and serve."
        );

        insertRecipeIngredient(db, recipe9, "tomato", 3, "pcs");
        insertRecipeIngredient(db, recipe9, "onion", 1, "pcs");


        // =====================================================
        // 10. RICE AND BEANS
        // =====================================================

        long recipe10 = insertRecipe(
                db,
                "Rice and Beans",
                "1. Cook the rice.\n" +
                        "2. Cook the beans.\n" +
                        "3. Season to taste.\n" +
                        "4. Serve the rice with the beans."
        );

        insertRecipeIngredient(db, recipe10, "rice", 200, "g");
        insertRecipeIngredient(db, recipe10, "beans", 200, "g");
    }


    // =========================================================
    // INTERNAL RECIPE INSERT
    // =========================================================

    private long insertRecipe(
            SQLiteDatabase db,
            String name,
            String steps) {

        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("steps", steps);

        return db.insert(
                "recipes",
                null,
                values
        );
    }


    // =========================================================
    // INTERNAL RECIPE INGREDIENT INSERT
    // =========================================================

    private long insertRecipeIngredient(
            SQLiteDatabase db,
            long recipeId,
            String name,
            double quantity,
            String unit) {

        ContentValues values = new ContentValues();

        values.put("recipe_id", recipeId);
        values.put("name", name);
        values.put("quantity", quantity);
        values.put("unit", unit);

        return db.insert(
                "recipe_ingredients",
                null,
                values
        );
    }
}