package com.example.smartpantry;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.Locale;

public class AddEditIngredientActivity extends AppCompatActivity {

    private EditText etName, etQuantity, etUnit, etExpiry;
    private DBHelper db;
    private int ingredientId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        initViews();
        setupActionBar();
        setupDatePicker();
        extractIntentData();
    }

    private void initViews() {
        db = new DBHelper(this);

        etName = findViewById(R.id.etName);
        etQuantity = findViewById(R.id.etQuantity);
        etUnit = findViewById(R.id.etUnit);
        etExpiry = findViewById(R.id.etExpiry);

        Button btnSave = findViewById(R.id.btnSave);
        if (btnSave != null) {
            btnSave.setOnClickListener(v -> saveIngredient());
        }
    }

    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(ingredientId == -1 ? "Add Ingredient" : "Edit Ingredient");
        }
    }

    private void extractIntentData() {
        if (getIntent().hasExtra("id")) {
            ingredientId = getIntent().getIntExtra("id", -1);

            if (etName != null) etName.setText(getIntent().getStringExtra("name"));
            if (etQuantity != null) {
                double qty = getIntent().getDoubleExtra("quantity", 0);
                etQuantity.setText(qty % 1 == 0 ? String.format(Locale.US, "%.0f", qty) : String.valueOf(qty));
            }
            if (etUnit != null) etUnit.setText(getIntent().getStringExtra("unit"));
            if (etExpiry != null) etExpiry.setText(getIntent().getStringExtra("expiry"));

            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.setTitle("Edit Ingredient");
            }
        }
    }

    private void setupDatePicker() {
        if (etExpiry == null) return;

        etExpiry.setFocusable(false);
        etExpiry.setClickable(true);
        etExpiry.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    AddEditIngredientActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        String formattedDate = String.format(Locale.US, "%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
                        etExpiry.setText(formattedDate);
                    },
                    year, month, day
            );
            datePickerDialog.show();
        });
    }

    private void saveIngredient() {
        String name = etName != null ? etName.getText().toString().trim() : "";
        String qtyStr = etQuantity != null ? etQuantity.getText().toString().trim() : "";
        String unit = etUnit != null ? etUnit.getText().toString().trim() : "";
        String expiry = etExpiry != null ? etExpiry.getText().toString().trim() : "";

        boolean isValid = true;

        if (TextUtils.isEmpty(name)) {
            if (etName != null) etName.setError("Ingredient name is required");
            isValid = false;
        }

        if (TextUtils.isEmpty(qtyStr)) {
            if (etQuantity != null) etQuantity.setError("Quantity is required");
            isValid = false;
        }

        if (TextUtils.isEmpty(unit)) {
            if (etUnit != null) etUnit.setError("Unit of measure is required");
            isValid = false;
        }

        if (!isValid) return;

        double quantity;
        try {
            quantity = Double.parseDouble(qtyStr);
        } catch (NumberFormatException e) {
            if (etQuantity != null) etQuantity.setError("Enter a valid numeric quantity");
            return;
        }

        if (ingredientId == -1) {
            db.addIngredient(name, quantity, unit, expiry);
            Toast.makeText(this, "Successfully added ingredient", Toast.LENGTH_SHORT).show();
        } else {
            db.updateIngredient(ingredientId, name, quantity, unit, expiry);
            Toast.makeText(this, "Successfully updated ingredient", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            getOnBackPressedDispatcher().onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}