package com.example.smartpantry;

import java.util.List;

public class Recipe {
    public int id;
    public String name, steps;
    public List<RecipeIngredient> ingredients;

    public Recipe(int id, String name, List<RecipeIngredient> ingredients, String steps) {
        this.id = id;
        this.name = name;
        this.ingredients = ingredients;
        this.steps = steps;
    }

    public static class RecipeIngredient {
        public String name, unit;
        public double quantity;

        public RecipeIngredient(String name, double quantity, String unit) {
            this.name = name;
            this.quantity = quantity;
            this.unit = unit;
        }
    }
}