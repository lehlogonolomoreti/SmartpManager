package com.example.smartpantry;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class SettingsActivity extends AppCompatActivity {

    private SwitchMaterial switchAlerts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        switchAlerts = findViewById(R.id.switch_expiry_alerts);
        SharedPreferences prefs = getSharedPreferences("SmartPantryPrefs", MODE_PRIVATE);

        if (switchAlerts != null) {
            switchAlerts.setChecked(prefs.getBoolean("EXPIRY_ALERTS", true));

            switchAlerts.setOnCheckedChangeListener((buttonView, isChecked) -> {
                prefs.edit().putBoolean("EXPIRY_ALERTS", isChecked).apply();
                Toast.makeText(this, "Preference saved", Toast.LENGTH_SHORT).show();
            });
        }

        setupNavigation();
    }

    private void setupNavigation() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        if (bottomNav == null) return;

        bottomNav.setSelectedItemId(R.id.nav_settings);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_pantry) {
                // FIXED: Changed PantryListActivity to MainActivity based on your project files
                startActivity(new Intent(this, MainActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_recipes) {
                startActivity(new Intent(this, SuggestedRecipesActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_settings) {
                return true;
            }
            return false;
        });
    }
}