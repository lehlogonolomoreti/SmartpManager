# Smart Pantry Manager

Java Android application for Mobile App Development 700.

## Features
- Pantry Create, Read, Update and Delete (CRUD)
- SQLite persistence
- RecyclerView with custom adapters
- 18 seeded recipes
- Strict recipe matching: every required ingredient and required quantity must be available
- Basic singular/plural normalization and unit conversion
- Recipe details
- Settings screen with expiry-alert preference
- Input validation
- Intent-based navigation

## Database choice
SQLite was selected because it is local, reliable, offline-friendly and directly aligned with the module requirement for persistent on-device storage.

## Run
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Create/start an Android emulator (API 24+).
4. Run the `app` configuration.

## Important assignment note
The brief requires a public GitHub repository and at least 10 genuine incremental commits. This ZIP cannot create those historical commits for you. After opening the project, initialise Git and commit development milestones as you work.

## Assignment source
The implementation follows the supplied Mobile App Development 700 Smart Pantry Manager brief, including the strict-matching rule and SQLite CRUD requirements.
